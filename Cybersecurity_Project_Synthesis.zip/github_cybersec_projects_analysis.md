# Cybersecurity Projects Analysis - girdav01

**Analysis Date:** 2026-02-12 13:33:32 UTC
**Filter Criteria:** Projects created or updated after November 12, 2025
**Total Projects Found:** 21

---

## V1Databricks

**Repository URL:** [https://github.com/girdav01/V1Databricks](https://github.com/girdav01/V1Databricks)

### Overview
- **Description:** Integrations between TrendAI Vision One and Databricks
- **Primary Language:** Python
- **Created:** 2026-02-12T04:09:25Z
- **Last Updated:** 2026-02-12T13:14:07Z

### Purpose and Functionality
Comprehensive security integration that forwards all Databricks audit logs, security events, and observables to the Trend Vision One Agentic SIEM platform. Deploys custom detection filters and models purpose-built for Databricks threat scenarios, calculates a Cyber Risk Index, and monitors AI application security across the full Databricks ecosystem. The integration implements a **three-layer security model** that maps to the Databricks platform architecture: ``` TREND VISION ONE PLATFORM ┌──────────────────────────────────────────────────────────────┐

### Key Features and Capabilities
- Features not explicitly documented in README

### Technologies and Frameworks
**Language Distribution:**
- Python: 100.0%

### Architecture and Structure
**Root Directory Structure:**
- Directories: config, src, tests
- Key Files: .env.example, .gitignore, LICENSE, README.md, Trend Vision One Protection For Databricks Ecosystem.docx, main.py, requirements.txt

### Documentation
**README Excerpt:**
```
# V1Databricks - Trend Vision One Integration for Databricks

Comprehensive security integration that forwards all Databricks audit logs, security events, and observables to the Trend Vision One Agentic SIEM platform. Deploys custom detection filters and models purpose-built for Databricks threat scenarios, calculates a Cyber Risk Index, and monitors AI application security across the full Databricks ecosystem.

## Architecture

The integration implements a **three-layer security model** that maps to the Databricks platform architecture:

```
 TREND VISION ONE PLATFORM
 ┌──────────────────────────────────────────────────────────────┐
 │  CREM (Risk Index)  |  SecOps (XDR/SIEM)  |  Companion (AI) │
 └────────────────────────────┬─────────────────────────────────┘
                              │
 DATABRICKS DATA INTELLIGENCE PLATFORM
 ┌────────────────────────────┴─────────────────────────────────┐
 │                                                              │
 │  Layer 3 - APPLICATION LAYER                                 │
 │  ├── Notebooks & Repos ──────► Code Security                 │
 │  ├── Mosaic AI / Serving ────► AI App Security               │
 │  └── MLflow Registry ────────► AI Security Monitor           │
 │                                                              │
 │  Layer 2 - CONTROL PLANE                                     │
 │  ├── Unity Catalog ──────────► Identity Security + CREM      │
 │  ├── System Tables ──────────► Agentic SIEM (XDR)            │
 │  └── IAM / Users ────────────► Identity Collector            │
 │                                                              │
 │  Layer 1 - DATA PLANE                                        │
 │  ├── Storage (S3/ADLS/GCS) ──► Cloud Infra Collector         │
 │  └── Compute Clusters ───────► Container + Workload Security │
... (truncated)
```

---

## AISECTraining

**Repository URL:** [https://github.com/girdav01/AISECTraining](https://github.com/girdav01/AISECTraining)

### Overview
- **Description:** Training on GenAI security
- **Primary Language:** TypeScript
- **Created:** 2026-01-09T04:53:08Z
- **Last Updated:** 2026-02-11T20:14:21Z

### Purpose and Functionality
**AISECTraining** is a hands-on educational workshop repository focused on GenAI application security. The workshop teaches developers how to build AI-powered applications while understanding and mitigating security vulnerabilities defined in the OWASP LLM Top 10. - ✅ **Complete OWASP LLM Top 10 Coverage** - All 10 risks covered across 6 practical exercises - 🎯 **Hands-on Learning** - Build, attack, secure, and verify in each exercise - 🔒 **Dual Security Approaches** - Learn both built-in controls and commercial solutions (Trend Vision One) - 🌐 **Flexible LLM Support** - Works with OpenAI API, Ollama, and LM Studio

### Key Features and Capabilities
- ✅ **Complete OWASP LLM Top 10 Coverage** - All 10 risks covered across 6 practical exercises
- 🎯 **Hands-on Learning** - Build, attack, secure, and verify in each exercise
- 🔒 **Dual Security Approaches** - Learn both built-in controls and commercial solutions (Trend Vision One)
- 🌐 **Flexible LLM Support** - Works with OpenAI API, Ollama, and LM Studio
- 📚 **Progressive Difficulty** - From basic chatbots to complex multi-agent systems

### Technologies and Frameworks
**Language Distribution:**
- TypeScript: 37.7%
- HTML: 31.4%
- Python: 30.3%
- CSS: 0.5%
- JavaScript: 0.1%

### Architecture and Structure
**Root Directory Structure:**
- Directories: genai_workshop, genai_workshop_ppt
- Key Files: .DS_Store, .gitignore, LICENSE, README.md, WORKSHOP_FLOW.md

### Documentation
**README Excerpt:**
```
# AI Security Training Workshop

## Project Overview

**AISECTraining** is a hands-on educational workshop repository focused on GenAI application security. The workshop teaches developers how to build AI-powered applications while understanding and mitigating security vulnerabilities defined in the OWASP LLM Top 10.

### Key Features
- ✅ **Complete OWASP LLM Top 10 Coverage** - All 10 risks covered across 6 practical exercises
- 🎯 **Hands-on Learning** - Build, attack, secure, and verify in each exercise
- 🔒 **Dual Security Approaches** - Learn both built-in controls and commercial solutions (Trend Vision One)
- 🌐 **Flexible LLM Support** - Works with OpenAI API, Ollama, and LM Studio
- 📚 **Progressive Difficulty** - From basic chatbots to complex multi-agent systems

## Architecture

```
┌────────────────────────────────────────────────────────────────────────────┐
│                        WORKSHOP ARCHITECTURE                               │
├────────────────────────────────────────────────────────────────────────────┤
│                                                                            │
│   ┌─────────────┐    ┌─────────────┐    ┌─────────────────────────────┐  │
│   │   OpenAI    │ OR │   Ollama    │    │    Trend Vision One         │  │
│   │   API       │    │   Local     │    │    AI Application Security  │  │
│   │  (Cloud)    │    │  (gemma:2b) │    │    (AI Scanner + AI Guard)  │  │
│   └──────┬──────┘    └──────┬──────┘    └──────────────┬──────────────┘  │
│          │                  │                          │                  │
│          └────────┬─────────┴──────────────────────────┘                  │
│                   │                                                       │
│                   ▼                                                       │
│   ┌─────────────────────────────────────────────────────────────────────┐ │
... (truncated)
```

---

## AutomatedSOC

**Repository URL:** [https://github.com/girdav01/AutomatedSOC](https://github.com/girdav01/AutomatedSOC)

### Overview
- **Description:** Automated SOC
- **Primary Language:** Python
- **Created:** 2026-02-10T19:07:27Z
- **Last Updated:** 2026-02-10T21:19:22Z

### Purpose and Functionality
An **OpenClaw-style** agentic triage agent in Python: it uses an LLM + **tools** (Vision One API) and **skills** (triage, notifications) to act like a SOC analyst. On a **regular basis** it checks for new **workbench alerts**, focuses on the **top riskiest assets**, and either **closes** alerts or **suggests response actions and mitigations** to human SOC operators. After each run it can send **mini-summaries** to one or multiple **on-duty SOC analysts** (email, Slack, Teams, optional WhatsApp) based on a **schedule/roster**. - **Alert ingestion**: New alerts (workbenches) can be pulled on a schedule (**pull** / polling) or delivered via **webhook** when Vision One (or your SIEM) pushes events. The agent consumes the same workbench data either way. - **Risk prioritization**: The agent targets the **top riskiest assets** first—using severity, scope, and context—so SOC effort is focused where it matters most. - **Actions**: For each alert the agent can **close** it (e.g. True Positive, False Positive, Resolved) or **suggest response actions and mitigations** (isolate endpoint, block hash, etc.). Sensitive actions can require human approval (see config). - **Threat intelligence**: External TI (e.g. **VirusTotal**, and other TI sources) can be used to **enrich** indicators and **motivate** the decisions (close vs. escalate, suggested mitigations) that the agent proposes to human SOC operators.

### Key Features and Capabilities
- **Agent loop**: LLM decides which Vision One operations to call (list alerts, get details, update status, isolate endpoint, etc.).
- **Tools**: `list_alerts` (with `order_by` for riskiest first), `get_alert`, `update_alert_status`, `search_detections`, `isolate_endpoint`, `restore_endpoint`, `terminate_process`.
- **Skills**: Triage (run the agent), Notification (send summary to on-duty analysts).
- **Roster/schedule**: YAML defines analysts, their shifts (weekday + time range), and delivery channels (email, Slack, Teams).
- **Integrations**: Email (SMTP), Slack (bot token or webhook), Microsoft Teams (incoming webhook). Optional WhatsApp via Twilio.
- **Threat intelligence (planned)**: VirusTotal and other TI sources for enriching indicators and motivating triage decisions.
- **Vision One APIs**: The [Vision One Search API](References/VisionOne-api-open-v3.0.json) and other Trend Vision One APIs (see **References** below) can be used to extend the agent’s capabilities.

### Technologies and Frameworks
**Language Distribution:**
- Python: 100.0%

### Architecture and Structure
**Root Directory Structure:**
- Directories: References, agent, api, config, llm, notifications, skills, tools, vision_one
- Key Files: .env.example, .gitignore, LICENSE, README.md, pyrightconfig.json, requirements.txt, run.py, run_webhook.py

### Documentation
**README Excerpt:**
```
# Automated Triage – Agentic SOC Triage for Trend Vision One

An **OpenClaw-style** agentic triage agent in Python: it uses an LLM + **tools** (Vision One API) and **skills** (triage, notifications) to act like a SOC analyst. On a **regular basis** it checks for new **workbench alerts**, focuses on the **top riskiest assets**, and either **closes** alerts or **suggests response actions and mitigations** to human SOC operators. After each run it can send **mini-summaries** to one or multiple **on-duty SOC analysts** (email, Slack, Teams, optional WhatsApp) based on a **schedule/roster**.

## Design

- **Alert ingestion**: New alerts (workbenches) can be pulled on a schedule (**pull** / polling) or delivered via **webhook** when Vision One (or your SIEM) pushes events. The agent consumes the same workbench data either way.
- **Risk prioritization**: The agent targets the **top riskiest assets** first—using severity, scope, and context—so SOC effort is focused where it matters most.
- **Actions**: For each alert the agent can **close** it (e.g. True Positive, False Positive, Resolved) or **suggest response actions and mitigations** (isolate endpoint, block hash, etc.). Sensitive actions can require human approval (see config).
- **Threat intelligence**: External TI (e.g. **VirusTotal**, and other TI sources) can be used to **enrich** indicators and **motivate** the decisions (close vs. escalate, suggested mitigations) that the agent proposes to human SOC operators.
- **Human-in-the-loop**: All proposals (status updates, containment, mitigations) are presented to SOC operators via the mini-summary and optional approval flow; the agent supports analysts rather than acting fully autonomously.

## Features

- **Agent loop**: LLM decides which Vision One operations to call (list alerts, get details, update status, isolate endpoint, etc.).
- **Tools**: `list_alerts` (with `order_by` for riskiest first), `get_alert`, `update_alert_status`, `search_detections`, `isolate_endpoint`, `restore_endpoint`, `terminate_process`.
- **Skills**: Triage (run the agent), Notification (send summary to on-duty analysts).
- **Roster/schedule**: YAML defines analysts, their shifts (weekday + time range), and delivery channels (email, Slack, Teams).
- **Integrations**: Email (SMTP), Slack (bot token or webhook), Microsoft Teams (incoming webhook). Optional WhatsApp via Twilio.
- **Threat intelligence (planned)**: VirusTotal and other TI sources for enriching indicators and motivating triage decisions.
- **Vision One APIs**: The [Vision One Search API](References/VisionOne-api-open-v3.0.json) and other Trend Vision One APIs (see **References** below) can be used to extend the agent’s capabilities.

## Requirements

- Python 3.10+
- Trend Vision One API token (Administration → API Keys; e.g. Analyst or Senior Analyst role).
- LLM: OpenAI API or **LiteLLM** (OpenAI-compatible); set `OPENAI_API_BASE_URL` for LiteLLM.

## Setup

... (truncated)
```

---

## VisionOneSkills

**Repository URL:** [https://github.com/girdav01/VisionOneSkills](https://github.com/girdav01/VisionOneSkills)

### Overview
- **Description:** Vision One Skills prototype
- **Primary Language:** Python
- **Created:** 2026-01-28T14:46:40Z
- **Last Updated:** 2026-02-10T06:16:34Z

### Purpose and Functionality
**A comprehensive endpoint skills framework for Trend Micro Vision One** Inspired by osquery Fleet's control plane and Claude Code Skills' declarative packaging model, this framework enables deployment and management of cybersecurity monitoring skills across your endpoint fleet (Windows, macOS, Linux). This framework provides: - **7 Production-Ready Skills** for AI/Shadow IT security monitoring - **Agentic SIEM Integration** with CEF output format

### Key Features and Capabilities
- Features not explicitly documented in README

### Technologies and Frameworks
**Language Distribution:**
- Python: 31.2%
- Shell: 30.7%
- PowerShell: 28.2%
- Go: 9.0%
- Makefile: 0.9%

### Architecture and Structure
**Root Directory Structure:**
- Directories: client, deployment, docs, examples, executor, siem, skills, webapp
- Key Files: I need to create something that is a mixed of OSQU.md, LICENSE, README.md, ROADMAP.md, requirements.txt, skill_dispatcher.py

### Documentation
**README Excerpt:**
```
# Vision One Cybersecurity Skills Framework

**A comprehensive endpoint skills framework for Trend Micro Vision One**

Inspired by osquery Fleet's control plane and Claude Code Skills' declarative packaging model, this framework enables deployment and management of cybersecurity monitoring skills across your endpoint fleet (Windows, macOS, Linux).

## Overview

This framework provides:

- **7 Production-Ready Skills** for AI/Shadow IT security monitoring
- **Agentic SIEM Integration** with CEF output format
- **Custom Filters & Detection Models** for Vision One Workbench
- **MITRE ATT&CK + ATLAS Mapping** for threat correlation
- **Cross-Platform Support** (Windows PowerShell, Linux Bash)
- **Persistent Deployment** via systemd/Task Scheduler

## Skills Catalog

| # | Skill | Purpose | Frequency | MITRE Coverage |
|---|-------|---------|-----------|----------------|
| 01 | **Shadow AI Monitor** | Detect local LLMs (Ollama, LM Studio, vLLM), model files, API proxies, risky models | 15m | T1204.002, T1071.001, T1105 |
| 02 | **Browser DR Monitor** | Sandbox escapes, code injection, risky downloads | 5m | T1055.001, T1189 |
| 03 | **AI Vibe Coding Monitor** | Cursor, Claude Code, Windsurf, API key exposure, unreviewed code, risky deps | 15m | T1552.001, T1195.002 |
| 04 | **AI Data Integrity Monitor** | Training data protection, model exfiltration, PII detection, config integrity | 30m | T1048, T1567, T1565.001 |
| 05 | **AISEC Monitor** | OWASP LLM Top 10, prompt injection, excessive agency, MCP security | 2m | T1059, T1190, T1552 |
| 06 | **AI Telemetry Monitor** | OCSF schema telemetry, API key exposure, compliance gaps (NIST/OWASP/ATLAS) | 5m | T1552, T1562, AML.T0043-45 |
| 07 | **AI Supply Chain Monitor** | Model integrity, pickle risks, typosquatting, vulnerable deps, pipeline security | 30m | T1195, AML.T0010, AML.T0018 |

## Quick Start
... (truncated)
```

---

## AIDisco

**Repository URL:** [https://github.com/girdav01/AIDisco](https://github.com/girdav01/AIDisco)

### Overview
- **Description:** Endpoint AI discovery script
- **Primary Language:** Python
- **Created:** 2025-09-02T14:40:06Z
- **Last Updated:** 2026-02-10T01:48:26Z

### Purpose and Functionality
A comprehensive scanner designed to detect common Local Large Language Model (LLM) software installations on Windows, macOS, and Linux systems, including software hidden in **Docker/Podman containers** and **Windows WSL2** distributions. Available in both **Python** and **Go** versions. The Go version compiles to a single static binary with no runtime dependencies, making it ideal for deployment across diverse environments. The scanner includes SIGMA rules for threat detection and monitoring. - **Ollama**: Lightweight framework for running LLMs locally - **LM Studio**: Desktop application for running LLMs with GUI - **GPT4All**: Cross-platform desktop application for running local LLMs - **vLLM**: High-performance inference library for LLMs

### Key Features and Capabilities
- Features not explicitly documented in README

### Technologies and Frameworks
**Language Distribution:**
- Python: 66.5%
- Go: 33.1%
- Makefile: 0.3%

### Architecture and Structure
**Root Directory Structure:**
- Directories: ai_discovery_scan_go, assets, output, sigma_rules
- Key Files: .gitignore, LICENSE, README.md, ai_discovery_scan.log, ai_discovery_scan.py, config_example.json, example_log_collection.py, example_usage.py, gitignore, sample-text-report.png

### Documentation
**README Excerpt:**
```
<p align="center">
  <img src="assets/AIDisco-logo.png" alt="AI Discovery - Shadow AI Logo" width="700">
</p>

# AI Discovery Scanner

A comprehensive scanner designed to detect common Local Large Language Model (LLM) software installations on Windows, macOS, and Linux systems, including software hidden in **Docker/Podman containers** and **Windows WSL2** distributions. Available in both **Python** and **Go** versions. The Go version compiles to a single static binary with no runtime dependencies, making it ideal for deployment across diverse environments. The scanner includes SIGMA rules for threat detection and monitoring.

## Features

### Supported LLM Software
- **Ollama**: Lightweight framework for running LLMs locally
- **LM Studio**: Desktop application for running LLMs with GUI
- **GPT4All**: Cross-platform desktop application for running local LLMs
- **vLLM**: High-performance inference library for LLMs
- **AI Development Tools**: GitHub Copilot, Replit Ghostwriter, Windsurf, Tabnine, Zed, Continue, Cursor
- **AI Chat Applications**: ChatGPT, Claude, Google Gemini, Brave Leo, Poe, YouChat, Chatbox
- **Open Source AI Platforms**: Open WebUI, AnythingLLM, LibreChat, Jan, Text Generation WebUI, LocalAI, Llamafile, Faraday, NVIDIA Chat with RTX
- **AI Discord Bots**: ClawdBot, OpenClaw, MoltBot (all variants of the same software)
- **AI Workflow Automation**: n8n (with dedicated process, file, and environment variable detection)
- **Container AI Detection**: Docker and Podman container enumeration for 27+ AI images
- **WSL2 AI Detection**: Windows Subsystem for Linux scanning for hidden AI software
- Extensible architecture for adding more LLM software detection

### Detection Methods
- **File System Paths**: Scans common installation directories
- **Registry Keys**: Windows registry entries (Windows only)
- **Environment Variables**: Detects LLM-related environment variables
- **Process Names**: Identifies running LLM processes
- **Network Ports**: Detects active LLM services on common ports
... (truncated)
```

---

## AIDataGuard

**Repository URL:** [https://github.com/girdav01/AIDataGuard](https://github.com/girdav01/AIDataGuard)

### Overview
- **Description:** This project add AI Data security to Trend Vision One through rules and automation 
- **Primary Language:** TypeScript
- **Created:** 2025-12-19T01:59:01Z
- **Last Updated:** 2026-02-01T00:59:55Z

### Purpose and Functionality
This project adds AI Data security to Trend Vision One through rules and automation. AI Data Guard is a comprehensive security monitoring solution that integrates with Trend Micro Vision One to provide: - **File Integrity Monitoring**: Track and protect AI training data, ML models, and datasets - **Log Inspection Rules**: Detect security threats, credential leaks, and unauthorized access - **Endpoint Management**: Monitor and manage security endpoints

### Key Features and Capabilities
- 🔒 Encrypted storage of API tokens and sensitive credentials
- 📊 Real-time dashboard with security statistics
- 🛡️ Integrity monitoring rules for AI/ML assets
- 📝 Log inspection rules for threat detection
- 🚨 Alert management and notifications
- 🔐 Secure authentication with NextAuth
- 🎨 Modern UI built with Next.js and Tailwind CSS

### Technologies and Frameworks
**Language Distribution:**
- TypeScript: 99.4%
- CSS: 0.4%
- JavaScript: 0.1%

### Architecture and Structure
**Root Directory Structure:**
- Directories: demos, nextjs_space, sigma_rules, sigma_rules_backup
- Key Files: .abacus.donotdelete, .gitignore, DEDUPLICATION_SUMMARY.md, DEDUPLICATION_SUMMARY.pdf, LICENSE, README.md, SIGMA_RULES_SUMMARY.md, SIGMA_RULES_SUMMARY.pdf

### Documentation
**README Excerpt:**
```
# AI Data Guard

This project adds AI Data security to Trend Vision One through rules and automation.

## Overview

AI Data Guard is a comprehensive security monitoring solution that integrates with Trend Micro Vision One to provide:

- **File Integrity Monitoring**: Track and protect AI training data, ML models, and datasets
- **Log Inspection Rules**: Detect security threats, credential leaks, and unauthorized access
- **Endpoint Management**: Monitor and manage security endpoints
- **Alert Management**: Real-time security alerts and notifications
- **Configuration Management**: Secure API token management with encryption

## Features

- 🔒 Encrypted storage of API tokens and sensitive credentials
- 📊 Real-time dashboard with security statistics
- 🛡️ Integrity monitoring rules for AI/ML assets
- 📝 Log inspection rules for threat detection
- 🚨 Alert management and notifications
- 🔐 Secure authentication with NextAuth
- 🎨 Modern UI built with Next.js and Tailwind CSS

## Tech Stack

- **Framework**: Next.js 14
- **Database**: PostgreSQL with Prisma ORM
- **Authentication**: NextAuth.js
- **UI**: Tailwind CSS, Radix UI
... (truncated)
```

---

## AICrawler

**Repository URL:** [https://github.com/girdav01/AICrawler](https://github.com/girdav01/AICrawler)

### Overview
- **Description:** AI Crawler is aim at finding new AI Services or applications for feeding a repository that can be use for reputation and for Shadow AI discovery. It is a multi-agent system that will find and then investigate and report the findings into a repo or database. It can then pass this the a Detection engineer agent that will try to create detection rules
- **Primary Language:** Python
- **Created:** 2026-01-30T15:13:18Z
- **Last Updated:** 2026-01-30T21:45:06Z

### Purpose and Functionality
A multi-agent system for discovering AI services and applications, designed for Shadow AI detection and building AI service repositories. - **Multi-Agent Architecture**: Specialized agents for search, crawling, investigation, reporting, and detection rule generation - **Multiple AI Backends**: Support for Ollama, LM Studio, OpenAI, Anthropic, and 100+ providers via LiteLLM - **Open Source Search & Crawling**: Uses DuckDuckGo, SearXNG, BeautifulSoup, and Playwright - **Shadow AI Risk Analysis**: Automated security assessment with risk scoring

### Key Features and Capabilities
- **Multi-Agent Architecture**: Specialized agents for search, crawling, investigation, reporting, and detection rule generation
- **Multiple AI Backends**: Support for Ollama, LM Studio, OpenAI, Anthropic, and 100+ providers via LiteLLM
- **Open Source Search & Crawling**: Uses DuckDuckGo, SearXNG, BeautifulSoup, and Playwright
- **Shadow AI Risk Analysis**: Automated security assessment with risk scoring
- **Detection Rule Generation**: Creates Sigma, YARA, and Suricata rules
- **Container Ready**: Full Docker and docker-compose support

### Technologies and Frameworks
**Language Distribution:**
- Python: 98.4%
- Dockerfile: 1.6%

### Architecture and Structure
**Root Directory Structure:**
- Directories: config, src, tests
- Key Files: .dockerignore, .env.example, .gitignore, Dockerfile, LICENSE, README.md, docker-compose.yml, pyproject.toml

### Documentation
**README Excerpt:**
```
# AI Crawler

A multi-agent system for discovering AI services and applications, designed for Shadow AI detection and building AI service repositories.

## Features

- **Multi-Agent Architecture**: Specialized agents for search, crawling, investigation, reporting, and detection rule generation
- **Multiple AI Backends**: Support for Ollama, LM Studio, OpenAI, Anthropic, and 100+ providers via LiteLLM
- **Open Source Search & Crawling**: Uses DuckDuckGo, SearXNG, BeautifulSoup, and Playwright
- **Shadow AI Risk Analysis**: Automated security assessment with risk scoring
- **Detection Rule Generation**: Creates Sigma, YARA, and Suricata rules
- **Container Ready**: Full Docker and docker-compose support

## Quick Start

### Prerequisites

- Python 3.10+
- Ollama (for local AI) or API key for cloud providers

### Installation

```bash
# Clone the repository
git clone https://github.com/your-org/ai-crawler.git
cd ai-crawler

# Install dependencies
pip install -e .

... (truncated)
```

---

## AI-Intel-Feed

**Repository URL:** [https://github.com/girdav01/AI-Intel-Feed](https://github.com/girdav01/AI-Intel-Feed)

### Overview
- **Description:** Repos to post threat intelligence on AI software stack
- **Primary Language:** None
- **Created:** 2026-01-28T15:57:42Z
- **Last Updated:** 2026-01-28T15:57:43Z

### Purpose and Functionality
Repos to post threat intelligence on AI software stack

### Key Features and Capabilities
- Features not explicitly documented in README

### Technologies and Frameworks
- Primary: None

### Architecture and Structure
**Root Directory Structure:**
- Key Files: LICENSE

### Documentation
No README documentation available

---

## V1ShadowAI

**Repository URL:** [https://github.com/girdav01/V1ShadowAI](https://github.com/girdav01/V1ShadowAI)

### Overview
- **Description:** This is a Trend Vision One set of tools to detect Shadow AI and related AI activities using different existing controls available in the Trend offering
- **Primary Language:** Python
- **Created:** 2025-11-14T19:55:20Z
- **Last Updated:** 2026-01-27T17:49:41Z

### Purpose and Functionality
This is a Trend Vision One set of tools to detect Shadow AI and related AI activities using different existing controls available in the Trend offering

### Key Features and Capabilities
- Features not explicitly documented in README

### Technologies and Frameworks
**Language Distribution:**
- Python: 100.0%

### Architecture and Structure
**Root Directory Structure:**
- Directories: extracted_trend_vision
- Key Files: trend_vision_one_shadow_ai_detection (1).zip

### Documentation
No README documentation available

---

## AITelemetry

**Repository URL:** [https://github.com/girdav01/AITelemetry](https://github.com/girdav01/AITelemetry)

### Overview
- **Description:** AI Telemetry project. Create a standard for AI infrastructure, systems and apps to generate cybersecurity Telemetry.
- **Primary Language:** Python
- **Created:** 2024-11-29T20:13:50Z
- **Last Updated:** 2026-01-26T16:16:12Z

### Purpose and Functionality
A comprehensive project to establish a standard for AI infrastructure, systems, and applications to generate cybersecurity telemetry. This project aims to create a unified approach for collecting and managing telemetry data from AI systems to support compliance, security monitoring, and incident response. The initiative was initially presented to CoSAI TS 2 on November 12th, 2024. ``` AITelemetry/ ├── AI_Telemetry_RFC_2024.md          # RFC proposal document

### Key Features and Capabilities
- Features not explicitly documented in README

### Technologies and Frameworks
**Language Distribution:**
- Python: 91.5%
- HTML: 8.3%
- Dockerfile: 0.1%
- Mako: 0.1%

### Architecture and Structure
**Root Directory Structure:**
- Directories: ai_telemetry_collector
- Key Files: AI_Telemetry_RFC_2024.md, LICENSE, README.md, ai_dr_monitoring_research.md, ai_dr_monitoring_research.pdf, ai_ir_monitoring_research.md, ai_ir_monitoring_research.pdf, ai_monitoring_collection_framework.md, ai_monitoring_collection_framework.pdf, ai_monitoring_comprehensive_report.md

### Documentation
**README Excerpt:**
```
# AI Telemetry

A comprehensive project to establish a standard for AI infrastructure, systems, and applications to generate cybersecurity telemetry.

## Overview

This project aims to create a unified approach for collecting and managing telemetry data from AI systems to support compliance, security monitoring, and incident response. The initiative was initially presented to CoSAI TS 2 on November 12th, 2024.

## Project Structure

```
AITelemetry/
├── AI_Telemetry_RFC_2024.md          # RFC proposal document
├── ai_telemetry_collector/            # Reference implementation
│   ├── collectors/                    # Platform-specific collectors
│   ├── forwarders/                    # Data forwarders (Syslog, S3)
│   ├── ocsf/                          # OCSF schema implementation
│   ├── database/                      # Data persistence layer
│   └── docs/                          # Technical documentation
├── ai_monitoring_*.md/pdf             # Research documents
└── ai_*_research.md/pdf               # Supporting research
```

## Key Components

### RFC Specification

The [AI_Telemetry_RFC_2024.md](AI_Telemetry_RFC_2024.md) contains the formal RFC proposal outlining:
- Problem statement and motivation
- Proposed telemetry standards
... (truncated)
```

---

## AISupplyChain

**Repository URL:** [https://github.com/girdav01/AISupplyChain](https://github.com/girdav01/AISupplyChain)

### Overview
- **Description:** AI supply chain verifyer
- **Primary Language:** Python
- **Created:** 2026-01-06T21:13:20Z
- **Last Updated:** 2026-01-07T19:34:34Z

### Purpose and Functionality
A comprehensive platform for securing AI supply chains with CoSAI and OWASP guidance, featuring ML artifact signing and provenance tracking. This platform provides two tightly integrated products: 1. **AI Supply Chain Assurance Platform** - Central inventory, dependency management, control evaluation, and vendor risk management 2. **ML Artifact Signing & Provenance Module** - Cryptographic signing, lineage tracking, and policy enforcement for ML artifacts - **AI Asset Discovery**: Auto-discover AI models, datasets, and endpoints from registries, MLOps pipelines, and API gateways

### Key Features and Capabilities
- **AI Asset Discovery**: Auto-discover AI models, datasets, and endpoints from registries, MLOps pipelines, and API gateways
- **AI-BOM Management**: Generate and maintain AI Bill of Materials (CycloneDX format)
- **Control Evaluation**: Score AI systems against CoSAI controls and OWASP ML/LLM supply chain requirements
- **Vendor Risk Assessment**: Standardized assessments and attestation ingestion for AI vendors
- **Artifact Signing**: Sign models, datasets, prompts, configs, and evaluation artifacts
- **Lineage Tracking**: Cryptographically linked lineage from base model to deployment
- **Policy Enforcement**: CI/CD gates to ensure compliance before deployment

### Technologies and Frameworks
**Language Distribution:**
- Python: 87.7%
- JavaScript: 11.8%
- Dockerfile: 0.4%
- HTML: 0.1%
- CSS: 0.1%

### Architecture and Structure
**Root Directory Structure:**
- Directories: api, cli, common, examples, intelligence, platform, signing, ui
- Key Files: .env.example, .gitignore, ARCHITECTURE.md, CONTAINER_DEPLOYMENT.md, DEPLOYMENT.md, Dockerfile, FEATURES_SUMMARY.md, LICENSE, README.md, SECURITY.md

### Documentation
**README Excerpt:**
```
# AI Supply Chain Assurance Platform

A comprehensive platform for securing AI supply chains with CoSAI and OWASP guidance, featuring ML artifact signing and provenance tracking.

## Overview

This platform provides two tightly integrated products:

1. **AI Supply Chain Assurance Platform** - Central inventory, dependency management, control evaluation, and vendor risk management
2. **ML Artifact Signing & Provenance Module** - Cryptographic signing, lineage tracking, and policy enforcement for ML artifacts

## Key Features

- **AI Asset Discovery**: Auto-discover AI models, datasets, and endpoints from registries, MLOps pipelines, and API gateways
- **AI-BOM Management**: Generate and maintain AI Bill of Materials (CycloneDX format)
- **Control Evaluation**: Score AI systems against CoSAI controls and OWASP ML/LLM supply chain requirements
- **Vendor Risk Assessment**: Standardized assessments and attestation ingestion for AI vendors
- **Artifact Signing**: Sign models, datasets, prompts, configs, and evaluation artifacts
- **Lineage Tracking**: Cryptographically linked lineage from base model to deployment
- **Policy Enforcement**: CI/CD gates to ensure compliance before deployment

## Architecture

```
ai-supply-chain-platform/
├── platform/              # Core assurance platform
│   ├── asset/            # Asset discovery and modeling
│   ├── bom/              # AI-BOM/SBOM management
│   ├── controls/         # CoSAI and OWASP control engine
│   ├── vendor/           # Vendor risk management
... (truncated)
```

---

## IndirectPromptTester

**Repository URL:** [https://github.com/girdav01/IndirectPromptTester](https://github.com/girdav01/IndirectPromptTester)

### Overview
- **Description:** This project is to help test applications against Indirect Prompt attacks.
- **Primary Language:** Python
- **Created:** 2025-11-16T11:13:05Z
- **Last Updated:** 2026-01-07T05:11:14Z

### Purpose and Functionality
A comprehensive framework for generating and testing applications against indirect prompts. This tool helps security researchers and developers test how AI agents handle potentially malicious or manipulative prompts embedded in various file types. - **118 Curated Examples**: Most comprehensive database of prompt injection attacks - **Sourced from Research**: OWASP, Lakera, Microsoft Security, PayloadsAllTheThings, GitHub repos (0xk1h0/ChatGPT_DAN, verazuo/jailbreak_llms), academic papers, and real-world attacks - **21 Attack Vectors**: - **Zero-Click Attacks** ⭐: Auto-trigger when agents process content (8 examples)

### Key Features and Capabilities
- Features not explicitly documented in README

### Technologies and Frameworks
**Language Distribution:**
- Python: 98.0%
- Shell: 0.9%
- Makefile: 0.6%
- Dockerfile: 0.5%

### Architecture and Structure
**Root Directory Structure:**
- Directories: indirect_prompt_tester, scripts
- Key Files: .dockerignore, .gitignore, DOCKER.md, DOCKER_QUICKSTART.md, DOCKER_SUMMARY.md, Dockerfile, Makefile, PROJECT_STRUCTURE.md, PROMPT_DATABASE.md, QUICKSTART.md

### Documentation
**README Excerpt:**
```
# Indirect Prompt Tester Framework

A comprehensive framework for generating and testing applications against indirect prompts. This tool helps security researchers and developers test how AI agents handle potentially malicious or manipulative prompts embedded in various file types.

## Features

### Prompt Injection Database (NEW! 🔥)
- **118 Curated Examples**: Most comprehensive database of prompt injection attacks
- **Sourced from Research**: OWASP, Lakera, Microsoft Security, PayloadsAllTheThings, GitHub repos (0xk1h0/ChatGPT_DAN, verazuo/jailbreak_llms), academic papers, and real-world attacks
- **21 Attack Vectors**:
  - **Zero-Click Attacks** ⭐: Auto-trigger when agents process content (8 examples)
  - **Jailbreaks**: DAN 6.0-13.0, STAN, DUDE, Evil Confidant, EvilBOT (9 examples)
  - **Autonomous Agents** ⭐: Workflow/memory/task queue poisoning (6 examples)
  - **Code Execution**: Python, JavaScript, shell, reflection-based (9 examples)
  - **Obfuscation**: Base64, hex, Unicode homoglyphs, token smuggling (8 examples)
  - **System Leaks**: Prompt extraction techniques (6 examples)
  - Plus: Instruction override, information disclosure, API/search poisoning, and more
- **Difficulty-Graded**:
  - Beginner (15): Simple attacks for testing basics
  - Intermediate (48): Sophisticated techniques
  - Advanced (55): Complex multi-stage attacks
- **CLI & UI Integration**: Browse, search, and filter 118 prompts by category/vector/difficulty
- **Easy Updates**: Standalone script to refresh database with latest intelligence
- **Export Capabilities**: Export to CSV for analysis and test suites

See [PROMPT_DATABASE.md](PROMPT_DATABASE.md) for detailed documentation and examples.

### Part 1: File Generation & Distribution
- **CLI Interface**: Command-line tool for generating files with indirect prompts
- **Streamlit UI**: Web-based interface for creating and managing test files
... (truncated)
```

---

## AntiphishingGenAI

**Repository URL:** [https://github.com/girdav01/AntiphishingGenAI](https://github.com/girdav01/AntiphishingGenAI)

### Overview
- **Description:** Anti-phishing using Gen AI and Agentic
- **Primary Language:** Python
- **Created:** 2025-12-27T05:52:49Z
- **Last Updated:** 2025-12-29T05:36:27Z

### Purpose and Functionality
An innovative anti-phishing solution specifically designed to detect GenAI-generated phishing attempts using advanced machine learning and linguistic analysis. - **Multi-Model Support**: Works with both SaaS APIs (OpenAI, Anthropic, Google) and local models (transformers, sentence-transformers) - **AI-Generated Content Detection**: Identifies telltale signs of AI-generated phishing emails - **Linguistic Analysis**: Analyzes perplexity, burstiness, coherence, and other linguistic patterns - **URL & Domain Analysis**: Checks for suspicious URLs, typosquatting, and known phishing domains

### Key Features and Capabilities
- Features not explicitly documented in README

### Technologies and Frameworks
**Language Distribution:**
- Python: 100.0%

### Architecture and Structure
**Root Directory Structure:**
- Directories: antiphishing, examples, integrations, tests
- Key Files: .env.example, .gitignore, CONTRIBUTING.md, LICENSE, QUICKSTART.md, README.md, config.example.yaml, requirements-attachments.txt, requirements-integrations.txt, requirements-local.txt

### Documentation
**README Excerpt:**
```
# AntiphishingGenAI

An innovative anti-phishing solution specifically designed to detect GenAI-generated phishing attempts using advanced machine learning and linguistic analysis.

## Features

### Email Content Analysis
- **Multi-Model Support**: Works with both SaaS APIs (OpenAI, Anthropic, Google) and local models (transformers, sentence-transformers)
- **AI-Generated Content Detection**: Identifies telltale signs of AI-generated phishing emails
- **Linguistic Analysis**: Analyzes perplexity, burstiness, coherence, and other linguistic patterns
- **URL & Domain Analysis**: Checks for suspicious URLs, typosquatting, and known phishing domains
- **Metadata Analysis**: Examines email headers, sender reputation, and authentication records
- **Ensemble Scoring**: Combines multiple detection methods for higher accuracy

### Advanced Attachment Analysis 🆕
- **Malware Detection**: Identifies executables, scripts, macros, and packed/obfuscated files
- **Zero-Click Exploit Detection**: Detects PDF exploits, Office vulnerabilities, image parsing attacks, compression bombs
- **Prompt Injection Detection**: Finds hidden AI prompt injections in documents and images (OCR)
- **Multi-Format Support**: Analyzes PDFs, Office docs, images, archives, scripts, and more
- **Deep File Inspection**: PE analysis, entropy checks, suspicious API imports, polyglot detection

### Integration & Deployment
- **Email System Integrations**: Ready-made scanners for Gmail and Outlook/Hotmail
- **n8n Workflows**: Automated mailbox scanning with visual workflow editor
- **REST API**: Production-ready FastAPI server for integration
- **CLI Interface**: Command-line tool for batch processing
- **Real-time Detection**: Fast analysis suitable for email gateway integration
- **Flexible Architecture**: Extensible plugin system for custom analyzers

## How It Works
... (truncated)
```

---

## AgenticAIDR

**Repository URL:** [https://github.com/girdav01/AgenticAIDR](https://github.com/girdav01/AgenticAIDR)

### Overview
- **Description:** A Detection & Response SDK for Agentic AI
- **Primary Language:** Python
- **Created:** 2025-12-23T18:31:57Z
- **Last Updated:** 2025-12-25T17:25:37Z

### Purpose and Functionality
[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0) [![Python](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/) AgenticAIDR is an open-source Detection & Response SDK purpose-built for securing autonomous AI agents in production environments. As 69% of enterprises deploy agentic AI systems and 42% lack confidence in agent-to-system security controls, AgenticAIDR addresses a critical gap: visibility, governance, and real-time response to agent actions before they impact enterprise systems. Traditional security controls monitor what agents *say* (prompt injection, jailbreaks). Agentic AI broke this model—agents now *take actions* (API calls, data modification, privilege escalation, tool chaining). Existing detection/response platforms cannot track autonomous agent behavior at the speed and scale required. AgenticAIDR provides:

### Key Features and Capabilities
- Features not explicitly documented in README

### Technologies and Frameworks
**Language Distribution:**
- Python: 98.9%
- Shell: 0.9%
- Dockerfile: 0.2%

### Architecture and Structure
**Root Directory Structure:**
- Directories: deployment, docs, examples, k8s, scripts, sdk
- Key Files: .gitignore, AgenticAIDR PRDs Updated.pdf, COMPETITIVE_ANALYSIS.md, CONTRIBUTING.md, Dockerfile, LICENSE, MARKETING_PLAN.md, README.md, ROADMAP.md, docker-compose.airgap.yml

### Documentation
**README Excerpt:**
```
# AgenticAIDR - Detection & Response SDK for Agentic AI

[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![Python](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)

AgenticAIDR is an open-source Detection & Response SDK purpose-built for securing autonomous AI agents in production environments. As 69% of enterprises deploy agentic AI systems and 42% lack confidence in agent-to-system security controls, AgenticAIDR addresses a critical gap: visibility, governance, and real-time response to agent actions before they impact enterprise systems.

## Core Problem

Traditional security controls monitor what agents *say* (prompt injection, jailbreaks). Agentic AI broke this model—agents now *take actions* (API calls, data modification, privilege escalation, tool chaining). Existing detection/response platforms cannot track autonomous agent behavior at the speed and scale required.

## Solution

AgenticAIDR provides:

- **Real-time agent action tracking** with full execution context
- **Autonomous behavior detection** against baselines and policies
- **Pre-execution policy enforcement** with kill-switch mechanisms
- **Complete audit trails** for compliance (SOX, HIPAA, GDPR, AI Act)
- **Agentic AI-aware correlation** across tool chains and recursive loops
- **Drop-in SDK integration** with minimal code changes

## Key Features

### 🔍 PRD 1: Core SDK - Agent Instrumentation & Telemetry
- Zero-modification SDKs for seamless agent instrumentation
- Complete telemetry capture of every decision, tool call, and data access
- Framework agnostic - supports 9+ major agentic AI frameworks:
  - **LangChain** | **CrewAI** | **LlamaIndex** | **Anthropic SDK**
  - **Google ADK** | **Microsoft Semantic Kernel** | **Meta Llama** | **NVIDIA NeMo/NIMs**
... (truncated)
```

---

## AIHoneypot

**Repository URL:** [https://github.com/girdav01/AIHoneypot](https://github.com/girdav01/AIHoneypot)

### Overview
- **Description:** The AI Honeypot project goal is to demonstrate different vulnerable AI applications for use as honeypot or security control demos
- **Primary Language:** Python
- **Created:** 2024-11-29T20:24:07Z
- **Last Updated:** 2025-12-04T00:46:36Z

### Purpose and Functionality
The AI Honeypot project demonstrates different vulnerable AI applications for use as honeypot or security control demos. This project covers all 10 risks from the **OWASP Top 10 for Large Language Model Applications 2025**. This project provides interactive demonstrations of LLM security vulnerabilities. Each demo is designed to be educational and should only be run in a sandboxed environment. These demos help security professionals understand LLM attack vectors and can be used for: - Security awareness training - Honeypot deployments - Security control testing

### Key Features and Capabilities
- Features not explicitly documented in README

### Technologies and Frameworks
**Language Distribution:**
- Python: 94.6%
- Shell: 4.7%
- Dockerfile: 0.7%

### Architecture and Structure
**Root Directory Structure:**
- Key Files: .dockerignore, .gitignore, Dockerfile, Dockerfile.simple, LICENSE, LLM01-promptInjection.py, LLM01.py, LLM02-sensitiveInformationDisclosure.py, LLM03-supplyChainVulnerabilities.py, LLM04-dataAndModelPoisoning.py

### Documentation
**README Excerpt:**
```
# AIHoneypot

The AI Honeypot project demonstrates different vulnerable AI applications for use as honeypot or security control demos. This project covers all 10 risks from the **OWASP Top 10 for Large Language Model Applications 2025**.

## Overview

This project provides interactive demonstrations of LLM security vulnerabilities. Each demo is designed to be educational and should only be run in a sandboxed environment. These demos help security professionals understand LLM attack vectors and can be used for:
- Security awareness training
- Honeypot deployments
- Security control testing
- Red team exercises

📖 **For detailed step-by-step instructions on demonstrating each risk, see [USER_GUIDE.md](USER_GUIDE.md)**

## Prerequisites

### For Local Installation
- **Python 3.12** (recommended) or Python 3.9-3.11
  - Python 3.14+ is not compatible due to Pydantic V1 dependencies
- [Ollama](https://ollama.ai/) installed and running locally
- Required Python packages (install with `pip install -r requirements.txt`)

### For Docker Deployment
- Docker and Docker Compose installed
- At least 8GB RAM (for running LLM models)
- Sufficient disk space for models (several GB per model)

## OWASP Top 10 LLM 2025 Demos

### LLM01: Prompt Injection
... (truncated)
```

---

## cyberAgents

**Repository URL:** [https://github.com/girdav01/cyberAgents](https://github.com/girdav01/cyberAgents)

### Overview
- **Description:** Cyber Agents Specialists
- **Primary Language:** Python
- **Created:** 2025-11-11T15:41:37Z
- **Last Updated:** 2025-12-01T21:58:36Z

### Purpose and Functionality
A powerful multi-agent cybersecurity analysis system that leverages specialized AI agents to provide comprehensive security insights. Built to run locally with Ollama, LM Studio, or OpenAI-compatible APIs. - **🤖 Multi-Agent Architecture**: 9 specialized cybersecurity experts working in coordination - **🧠 Intelligent Orchestration**: Reasoning-based orchestrator using models like PHI-4 or GPT-4o - **🏠 Local Model Support**: Run completely offline with Ollama or LM Studio - **🎨 Streamlit Web UI**: Clean, intuitive interface for security analysis

### Key Features and Capabilities
- Features not explicitly documented in README

### Technologies and Frameworks
**Language Distribution:**
- Python: 94.4%
- Shell: 3.0%
- Batchfile: 2.0%
- Dockerfile: 0.6%

### Architecture and Structure
**Root Directory Structure:**
- Directories: config, docs, examples, scripts, src
- Key Files: .dockerignore, .env.example, .gitignore, DOCKER_DEPLOYMENT.md, Dockerfile, EXAMPLES.md, LICENSE, QUICKSTART.md, README.md, docker-compose.yml

### Documentation
**README Excerpt:**
```
# 🛡️ CyberAgents - Multi-Agent Cybersecurity System

A powerful multi-agent cybersecurity analysis system that leverages specialized AI agents to provide comprehensive security insights. Built to run locally with Ollama, LM Studio, or OpenAI-compatible APIs.

## 🌟 Features

- **🤖 Multi-Agent Architecture**: 9 specialized cybersecurity experts working in coordination
- **🧠 Intelligent Orchestration**: Reasoning-based orchestrator using models like PHI-4 or GPT-4o
- **🏠 Local Model Support**: Run completely offline with Ollama or LM Studio
- **🎨 Streamlit Web UI**: Clean, intuitive interface for security analysis
- **🔗 WebHook Integration**: Receive and analyze security events from external systems
- **💬 MCP Protocol Support**: Programmatic access via Model Context Protocol
- **⚡ Concurrent Execution**: Parallel agent execution for faster analysis
- **🔧 Highly Configurable**: YAML-based configuration for easy customization
- **🐳 Docker Deployment**: Complete containerized deployment with Docker Compose
- **🔍 Advanced Threat Intelligence**: Integration with OpenCTI, MISP, SpiderFoot, and Trend Vision One
- **📊 Enhanced System Prompts**: Advanced cybersecurity expert prompts with 15+ years expertise simulation

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    User Interfaces                       │
│  ┌──────────┐  ┌──────────┐  ┌──────────────────┐      │
│  │ Streamlit│  │ WebHook  │  │  MCP Server      │      │
│  │   UI     │  │  Server  │  │  (stdio/chat)    │      │
│  └────┬─────┘  └────┬─────┘  └────────┬─────────┘      │
└───────┼─────────────┼─────────────────┼─────────────────┘
        │             │                 │
        └─────────────┼─────────────────┘
... (truncated)
```

---

## AISEC

**Repository URL:** [https://github.com/girdav01/AISEC](https://github.com/girdav01/AISEC)

### Overview
- **Description:** AI security Framework
- **Primary Language:** Python
- **Created:** 2025-11-17T10:49:49Z
- **Last Updated:** 2025-11-17T16:22:17Z

### Purpose and Functionality
AI security Framework

### Key Features and Capabilities
- Features not explicitly documented in README

### Technologies and Frameworks
**Language Distribution:**
- Python: 100.0%

### Architecture and Structure
**Root Directory Structure:**
- Directories: secureai_framework
- Key Files: FRAMEWORK_SUMMARY.md

### Documentation
No README documentation available

---

## AIGuardAPIDemo

**Repository URL:** [https://github.com/girdav01/AIGuardAPIDemo](https://github.com/girdav01/AIGuardAPIDemo)

### Overview
- **Description:** No description
- **Primary Language:** None
- **Created:** 2025-11-17T09:59:46Z
- **Last Updated:** 2025-11-17T09:59:47Z

### Purpose and Functionality
No description

### Key Features and Capabilities
- Features not explicitly documented in README

### Technologies and Frameworks
- Primary: None

### Architecture and Structure
- Structure information not available

### Documentation
No README documentation available

---

## LieDetector

**Repository URL:** [https://github.com/girdav01/LieDetector](https://github.com/girdav01/LieDetector)

### Overview
- **Description:** This projects is trying to detect Fraud, Social Engineering, DeepFake, Disinformation
- **Primary Language:** Python
- **Created:** 2025-11-14T19:36:29Z
- **Last Updated:** 2025-11-16T01:52:33Z

### Purpose and Functionality
![SocialGuard](https://img.shields.io/badge/Security-SocialGuard-blue) ![Version](https://img.shields.io/badge/version-1.0.0-green) ![License](https://img.shields.io/badge/license-MIT-blue) **Real-time protection against social engineering attacks combining AI-powered trust scoring with just-in-time behavioral nudges.** SocialGuard is a comprehensive fraud detection and social engineering defense platform based on the [Unit 42 2025 Global Incident Response Report](https://unit42.paloaltonetworks.com/2025-unit-42-global-incident-response-report-social-engineering-edition/). It addresses the growing threat landscape where 36% of incidents start with social engineering.

### Key Features and Capabilities
- Features not explicitly documented in README

### Technologies and Frameworks
**Language Distribution:**
- Python: 48.8%
- JavaScript: 42.7%
- HTML: 6.8%
- CSS: 1.7%

### Architecture and Structure
**Root Directory Structure:**
- Directories: backend, docs, extension, frontend, ml_models
- Key Files: .gitignore, README.md, conversation.pdf

### Documentation
**README Excerpt:**
```
# SocialGuard - AI-Powered Social Engineering Defense Platform

![SocialGuard](https://img.shields.io/badge/Security-SocialGuard-blue)
![Version](https://img.shields.io/badge/version-1.0.0-green)
![License](https://img.shields.io/badge/license-MIT-blue)

**Real-time protection against social engineering attacks combining AI-powered trust scoring with just-in-time behavioral nudges.**

## 🎯 Overview

SocialGuard is a comprehensive fraud detection and social engineering defense platform based on the [Unit 42 2025 Global Incident Response Report](https://unit42.paloaltonetworks.com/2025-unit-42-global-incident-response-report-social-engineering-edition/). It addresses the growing threat landscape where 36% of incidents start with social engineering.

### Key Threats Addressed

- **ClickFix Attacks** - Fake system prompts and SEO poisoning
- **Help Desk Manipulation** - MFA bypass and account takeover
- **Voice Cloning** - AI-generated voice impersonation
- **Executive Impersonation** - CEO fraud and BEC attacks
- **Credential Phishing** - Sophisticated phishing campaigns

## 🏗️ Architecture

### Core Components

1. **Trust Scoring Engine** (FastAPI Backend)
   - Real-time risk assessment (0-100 score)
   - Multi-signal analysis (identity, content, behavior, context)
   - Redis caching for low-latency scoring

2. **Just-In-Time Nudges** (React Frontend)
... (truncated)
```

---

## UniversalGuardrail

**Repository URL:** [https://github.com/girdav01/UniversalGuardrail](https://github.com/girdav01/UniversalGuardrail)

### Overview
- **Description:** Universal Guardrail Standard and API 
- **Primary Language:** None
- **Created:** 2025-11-12T14:28:51Z
- **Last Updated:** 2025-11-12T14:28:51Z

### Purpose and Functionality
Universal Guardrail Standard and API 

### Key Features and Capabilities
- Features not explicitly documented in README

### Technologies and Frameworks
- Primary: None

### Architecture and Structure
- Structure information not available

### Documentation
No README documentation available

---

## DatasetScrapper

**Repository URL:** [https://github.com/girdav01/DatasetScrapper](https://github.com/girdav01/DatasetScrapper)

### Overview
- **Description:** This is an Agentic tool that search and gather data for AI model fine tuning or training
- **Primary Language:** Python
- **Created:** 2025-11-12T13:09:33Z
- **Last Updated:** 2025-11-12T13:55:41Z

### Purpose and Functionality
A secure, multi-role agentic system for generating high-quality cybersecurity training datasets using **local AI models** (Ollama/LM Studio) and web data collection (Crawl4ai). No cloud APIs required! This tool implements a multi-agent architecture where each agent represents a specialized cybersecurity role. It autonomously generates two types of datasets: 1. **Instruct Dataset**: Instruction-following samples for cybersecurity tasks 2. **Reasoning Dataset**: Multi-step reasoning traces for complex security analysis All samples include complete source provenance, security validation, and are ready for fine-tuning LLMs on cybersecurity tasks.

### Key Features and Capabilities
- Features not explicitly documented in README

### Technologies and Frameworks
**Language Distribution:**
- Python: 100.0%

### Architecture and Structure
**Root Directory Structure:**
- Directories: config, data, src
- Key Files: .env.example, .gitignore, LOCAL_AI_SETUP.md, README.md, USAGE.md, app.py, cli.py, requirements.txt, test_security.py

### Documentation
**README Excerpt:**
```
# 🔐 Cybersecurity Dataset Generator

A secure, multi-role agentic system for generating high-quality cybersecurity training datasets using **local AI models** (Ollama/LM Studio) and web data collection (Crawl4ai). No cloud APIs required!

## 🎯 Overview

This tool implements a multi-agent architecture where each agent represents a specialized cybersecurity role. It autonomously generates two types of datasets:

1. **Instruct Dataset**: Instruction-following samples for cybersecurity tasks
2. **Reasoning Dataset**: Multi-step reasoning traces for complex security analysis

All samples include complete source provenance, security validation, and are ready for fine-tuning LLMs on cybersecurity tasks.

## 🆕 NEW: Local AI Support

- **Local LLM Inference**: Run entirely on your RTX 4070 TI Super (or any modern GPU)
- **Recommended Models**: PHI4 (reasoning) or GPT-OSS:20B
- **Web Data Collection**: Crawl4ai (Docker-based) for real cybersecurity content
- **Organized Data Structure**: Separate directories for each agent's downloaded data
- **No Cloud Dependencies**: Everything runs locally!

## ✨ Features

### 🤖 Multi-Role Agents (9 Specialized Roles)

**Offensive Security:**
- Red Teamer - Advanced persistent threat simulation
- Malware Reverse Engineer - Binary analysis and IOC extraction
- Vulnerability & Bug Bounty Researcher - Zero-day discovery and disclosure

... (truncated)
```

---
